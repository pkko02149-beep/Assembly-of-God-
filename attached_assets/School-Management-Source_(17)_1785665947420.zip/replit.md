# School Management System

A comprehensive school management platform for admins, teachers, parents, and students. Handles fee collection, attendance, exam results, timetables, notices, homework, transport management, QR scanning, and more.

## Run & Operate

- `pnpm --filter @workspace/school-mgmt run dev` — run the frontend (port 18953)
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19, Vite, TailwindCSS, Wouter, TanStack Query, Shadcn UI
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Auth: JWT (admin + teacher + parent separate auth)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/school-mgmt/src/pages/` — all pages (public, admin, teacher, parent)
- `artifacts/school-mgmt/src/components/` — layouts (ParentLayout, TeacherLayout) and shared components
- `artifacts/api-server/src/routes/` — all API route handlers
- `artifacts/api-server/src/lib/` — auth middleware, JWT, mailer, push notifications
- `lib/db/src/schema/index.ts` — full database schema
- `lib/api-client-react/src/generated/` — generated React Query hooks

## Portals & Routes

- `/` — Public school website
- `/login` — Admin login
- `/admin` — Admin dashboard
- `/teacher/login` — Teacher login
- `/teacher` — Teacher dashboard
- `/parent/login` — Parent login
- `/parent` — Parent dashboard

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- The API server handles separate JWT auth for admin, teacher, and parent roles
- Academic sessions use a schema-per-session architecture (session_context.ts)
- Push `lib/db` schema before starting the API server on a fresh database
